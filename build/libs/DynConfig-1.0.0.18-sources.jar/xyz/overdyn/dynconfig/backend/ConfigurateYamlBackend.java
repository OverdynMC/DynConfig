package xyz.overdyn.dynconfig.backend;

import org.jetbrains.annotations.NotNull;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.NodeStyle;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * YAML backend using SpongePowered Configurate.
 * Provides clean integration with Configurate's node system.
 */
public final class ConfigurateYamlBackend implements ConfigBackend {

    @Override
    public @NotNull ConfigurationNode load(@NotNull Path path) throws IOException {
        // Ensure parent directory exists
        Path parent = path.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }

        YamlConfigurationLoader loader = YamlConfigurationLoader.builder()
                .path(path)
                .nodeStyle(NodeStyle.BLOCK)
                .build();

        // If file doesn't exist, return empty node
        if (!Files.exists(path)) {
            return loader.createNode();
        }

        return loader.load();
    }

    @Override
    public void save(@NotNull Path path, @NotNull ConfigurationNode root) throws IOException {
        // Ensure parent directory exists
        Path parent = path.getParent();
        if (parent != null && !Files.exists(parent)) {
            Files.createDirectories(parent);
        }

        YamlConfigurationLoader loader = YamlConfigurationLoader.builder()
                .path(path)
                .nodeStyle(NodeStyle.BLOCK)
                .build();

        loader.save(root);
    }
}
