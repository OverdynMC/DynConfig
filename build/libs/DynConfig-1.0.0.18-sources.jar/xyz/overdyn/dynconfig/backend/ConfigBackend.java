package xyz.overdyn.dynconfig.backend;

import org.jetbrains.annotations.NotNull;
import org.spongepowered.configurate.ConfigurationNode;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Backend abstraction for configuration storage.
 * Directly works with Configurate's ConfigurationNode.
 */
public interface ConfigBackend {

    /**
     * Loads configuration from file and returns root node.
     *
     * @param path file path
     * @return root configuration node
     * @throws IOException if file cannot be read
     */
    @NotNull ConfigurationNode load(@NotNull Path path) throws IOException;

    /**
     * Saves configuration node to file.
     *
     * @param path file path
     * @param root root configuration node
     * @throws IOException if file cannot be written
     */
    void save(@NotNull Path path, @NotNull ConfigurationNode root) throws IOException;
}
