package xyz.overdyn.dynconfig;

import org.jetbrains.annotations.NotNull;
import org.spongepowered.configurate.CommentedConfigurationNode;
import org.spongepowered.configurate.ConfigurationNode;
import xyz.overdyn.dynconfig.adapter.AdapterRegistry;
import xyz.overdyn.dynconfig.adapter.ConfigAdapter;
import xyz.overdyn.dynconfig.annotation.Comment;
import xyz.overdyn.dynconfig.annotation.ConfigIgnore;
import xyz.overdyn.dynconfig.annotation.ConfigKey;
import xyz.overdyn.dynconfig.annotation.ConfigResource;
import xyz.overdyn.dynconfig.backend.ConfigBackend;
import xyz.overdyn.dynconfig.backend.ConfigurateYamlBackend;
import xyz.overdyn.dynconfig.format.ConfigFormat;
import xyz.overdyn.dynconfig.policy.MissingKeyPolicy;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;

/**
 * Main configuration manager using SpongePowered Configurate.
 * Provides annotation-based configuration with automatic file generation,
 * multi-language comments, and custom type adapters.
 */
public final class ConfigManager {

    private static Path baseDir;
    private static final Map<ConfigFormat, ConfigBackend> backends = new EnumMap<>(ConfigFormat.class);
    private static final Map<Class<?>, Object> cache = new HashMap<>();

    private ConfigManager() {}

    static {
        registerBackend(ConfigFormat.YAML, new ConfigurateYamlBackend());
    }

    /**
     * Initializes the config manager with base directory.
     *
     * @param directory base directory for config files
     */
    public static void init(@NotNull Path directory) {
        baseDir = directory;
    }

    /**
     * Registers a backend for a specific format.
     *
     * @param format  config format
     * @param backend backend implementation
     */
    public static void registerBackend(@NotNull ConfigFormat format, @NotNull ConfigBackend backend) {
        backends.put(format, backend);
    }

    /**
     * Gets cached config instance or loads it from file.
     *
     * @param type config class
     * @param <T>  config type
     * @return config instance
     */
    @SuppressWarnings("unchecked")
    public static <T> @NotNull T get(@NotNull Class<T> type) {
        return (T) cache.computeIfAbsent(type, ConfigManager::loadInternal);
    }

    /**
     * Reloads config from file and updates cache.
     *
     * @param type config class
     * @param <T>  config type
     * @return reloaded config instance
     */
    public static <T> @NotNull T reload(@NotNull Class<T> type) {
        T current = get(type);
        save(type, current);
        T reloaded = loadInternal(type);
        cache.put(type, reloaded);
        return reloaded;
    }

    /**
     * Saves all cached configs to their files.
     */
    public static void saveAll() {
        cache.forEach(ConfigManager::save);
    }

    /**
     * Atomically updates and saves config.
     *
     * @param type    config class
     * @param mutator mutation function
     * @param <T>     config type
     */
    public static <T> void update(@NotNull Class<T> type, @NotNull Consumer<T> mutator) {
        T cfg = get(type);
        mutator.accept(cfg);
        save(type, cfg);
    }

    // ==================== INTERNAL ====================

    private static <T> @NotNull T loadInternal(@NotNull Class<T> type) {
        ConfigResource meta = validateConfigResource(type);
        ConfigBackend backend = getBackend(meta.format());
        Path path = resolvePath(meta);

        try {
            ConfigurationNode root = backend.load(path);
            T instance = createInstance(type);
            
            boolean modified = loadFields(instance, root, meta.missingKeyPolicy());
            applyComments(type, root);

            if (modified || !path.toFile().exists()) {
                backend.save(path, root);
            }

            return instance;
        } catch (IOException e) {
            throw new RuntimeException("[ConfigManager] Cannot load config: " + path, e);
        }
    }

    private static void save(@NotNull Class<?> type, @NotNull Object instance) {
        ConfigResource meta = validateConfigResource(type);
        ConfigBackend backend = getBackend(meta.format());
        Path path = resolvePath(meta);

        try {
            ConfigurationNode root = backend.load(path);
            saveFields(instance, root);
            applyComments(type, root);
            backend.save(path, root);
        } catch (IOException e) {
            throw new RuntimeException("[ConfigManager] Cannot save config: " + path, e);
        }
    }

    private static boolean loadFields(Object instance, ConfigurationNode root, MissingKeyPolicy policy) {
        boolean modified = false;
        Class<?> type = instance.getClass();

        for (Field field : type.getDeclaredFields()) {
            if (isIgnored(field)) continue;

            field.setAccessible(true);
            String key = resolveKey(field);
            Object[] path = key.split("\\.");

            ConfigurationNode node = root.node(path);
            Object currentValue = getFieldValue(instance, field);

            if (node.virtual()) {
                // Key missing in file
                if (policy == MissingKeyPolicy.WRITE_DEFAULT && currentValue != null) {
                    setNodeValue(node, currentValue, field.getType());
                    modified = true;
                } else if (policy == MissingKeyPolicy.ERROR) {
                    throw new IllegalStateException("[ConfigManager] Missing required key: " + key);
                }
                // USE_FIELD_DEFAULT: do nothing, keep field default
            } else {
                // Key exists in file
                Object value = getNodeValue(node, field.getType());
                setFieldValue(instance, field, value);
            }
        }

        return modified;
    }

    private static void saveFields(Object instance, ConfigurationNode root) {
        Class<?> type = instance.getClass();

        for (Field field : type.getDeclaredFields()) {
            if (isIgnored(field)) continue;

            field.setAccessible(true);
            String key = resolveKey(field);
            Object[] path = key.split("\\.");

            ConfigurationNode node = root.node(path);
            Object value = getFieldValue(instance, field);
            setNodeValue(node, value, field.getType());
        }
    }

    private static void applyComments(Class<?> type, ConfigurationNode root) {
        if (!(root instanceof CommentedConfigurationNode)) {
            return; // Backend doesn't support comments
        }

        String currentLang = LangContext.get();

        for (Field field : type.getDeclaredFields()) {
            if (isIgnored(field)) continue;

            Comment comment = field.getAnnotation(Comment.class);
            if (comment == null) continue;

            String key = resolveKey(field);
            Object[] path = key.split("\\.");
            ConfigurationNode node = root.node(path);

            if (node instanceof CommentedConfigurationNode commentedNode) {
                List<String> lines = resolveComment(comment, currentLang);
                if (!lines.isEmpty()) {
                    commentedNode.comment(String.join("\n", lines));
                }
            }
        }
    }

    // ==================== VALUE CONVERSION ====================

    @SuppressWarnings("unchecked")
    private static Object getNodeValue(ConfigurationNode node, Class<?> targetType) {
        Object raw = node.raw();
        if (raw == null) return null;

        // Check for custom adapter
        ConfigAdapter<Object> adapter = (ConfigAdapter<Object>) AdapterRegistry.get(targetType);
        if (adapter != null) {
            return adapter.fromConfig(raw);
        }

        // Handle primitives
        if (isPrimitive(targetType)) {
            return convertPrimitive(raw, targetType);
        }

        // Handle enums
        if (targetType.isEnum()) {
            return Enum.valueOf((Class<Enum>) targetType, raw.toString());
        }

        // Handle lists
        if (List.class.isAssignableFrom(targetType)) {
            if (raw instanceof List<?> list) {
                return new ArrayList<>(list);
            }
            return List.of(raw);
        }

        // Handle maps
        if (Map.class.isAssignableFrom(targetType)) {
            if (raw instanceof Map<?, ?> map) {
                return new LinkedHashMap<>(map);
            }
        }

        return raw;
    }

    @SuppressWarnings("unchecked")
    private static void setNodeValue(ConfigurationNode node, Object value, Class<?> sourceType) {
        try {
            if (value == null) {
                node.set(null);
                return;
            }

            // Check for custom adapter
            ConfigAdapter<Object> adapter = (ConfigAdapter<Object>) AdapterRegistry.get(sourceType);
            if (adapter != null) {
                node.set(adapter.toConfig(value));
                return;
            }

            // Handle primitives and enums directly
            if (isPrimitive(sourceType) || sourceType.isEnum() || value instanceof String) {
                node.set(value);
                return;
            }

            // Handle lists recursively
            if (value instanceof List<?> list) {
                List<Object> processed = new ArrayList<>(list);
                node.set(processed);
                return;
            }

            // Handle maps recursively
            if (value instanceof Map<?, ?> map) {
                Map<String, Object> processed = new LinkedHashMap<>();
                map.forEach((k, v) -> processed.put(k.toString(), v));
                node.set(processed);
                return;
            }

            // Default: set as-is
            node.set(value);
        } catch (Exception e) {
            throw new RuntimeException("[ConfigManager] Cannot serialize value: " + value, e);
        }
    }

    private static Object convertPrimitive(Object raw, Class<?> type) {
        if (raw == null) return null;

        String s = raw.toString();
        if (type == int.class || type == Integer.class) return Integer.parseInt(s);
        if (type == long.class || type == Long.class) return Long.parseLong(s);
        if (type == double.class || type == Double.class) return Double.parseDouble(s);
        if (type == float.class || type == Float.class) return Float.parseFloat(s);
        if (type == boolean.class || type == Boolean.class) {
            if (raw instanceof Boolean) return raw;
            return Boolean.parseBoolean(s);
        }
        if (type == String.class) return s;

        return raw;
    }

    private static boolean isPrimitive(Class<?> type) {
        return type.isPrimitive()
                || type == Integer.class
                || type == Long.class
                || type == Double.class
                || type == Float.class
                || type == Boolean.class
                || type == String.class;
    }

    // ==================== COMMENT RESOLUTION ====================

    private static List<String> resolveComment(Comment comment, String lang) {
        if (lang == null || lang.isBlank()) {
            lang = "en";
        }
        lang = lang.toLowerCase(Locale.ROOT);

        Comment.Entry fallback = null;
        for (Comment.Entry entry : comment.value()) {
            if (entry.lang().equalsIgnoreCase(lang)) {
                return Arrays.asList(entry.lines());
            }
            if (entry.lang().equalsIgnoreCase("en") || entry.lang().equalsIgnoreCase("default")) {
                fallback = entry;
            }
        }

        return fallback != null ? Arrays.asList(fallback.lines()) : Collections.emptyList();
    }

    // ==================== REFLECTION HELPERS ====================

    private static String resolveKey(Field field) {
        ConfigKey annotation = field.getAnnotation(ConfigKey.class);
        return annotation != null ? annotation.value() : field.getName();
    }

    private static boolean isIgnored(Field field) {
        return field.isAnnotationPresent(ConfigIgnore.class) || Modifier.isStatic(field.getModifiers());
    }

    private static <T> T createInstance(Class<T> type) {
        try {
            return type.getDeclaredConstructor().newInstance();
        } catch (Exception e) {
            throw new RuntimeException("[ConfigManager] Cannot instantiate " + type.getName() + 
                    ". Ensure it has a no-args constructor.", e);
        }
    }

    private static Object getFieldValue(Object instance, Field field) {
        try {
            return field.get(instance);
        } catch (Exception e) {
            throw new RuntimeException("[ConfigManager] Cannot read field: " + field.getName(), e);
        }
    }

    private static void setFieldValue(Object instance, Field field, Object value) {
        try {
            field.set(instance, value);
        } catch (Exception e) {
            throw new RuntimeException("[ConfigManager] Cannot set field: " + field.getName() + 
                    " to value: " + value, e);
        }
    }

    // ==================== VALIDATION ====================

    private static ConfigResource validateConfigResource(Class<?> type) {
        ConfigResource meta = type.getAnnotation(ConfigResource.class);
        if (meta == null) {
            throw new IllegalStateException("[ConfigManager] Class " + type.getName() + 
                    " must be annotated with @ConfigResource");
        }
        return meta;
    }

    private static ConfigBackend getBackend(ConfigFormat format) {
        ConfigBackend backend = backends.get(format);
        if (backend == null) {
            throw new IllegalStateException("[ConfigManager] No backend registered for format: " + format);
        }
        return backend;
    }

    private static Path resolvePath(ConfigResource meta) {
        if (baseDir == null) {
            throw new IllegalStateException("[ConfigManager] ConfigManager.init(baseDir) must be called first");
        }

        String pathStr = meta.path();
        
        // Replace {lang} placeholder
        if (pathStr.contains("{lang}")) {
            pathStr = pathStr.replace("{lang}", LangContext.get());
        }

        return baseDir.resolve(pathStr);
    }
}
